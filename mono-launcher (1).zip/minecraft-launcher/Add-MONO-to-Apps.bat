@echo off
cd /d "%~dp0"
echo Adding MONO to your Start menu and desktop...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Add-MONO-to-Apps.ps1"
if errorlevel 1 ( echo Something went wrong. & pause & exit /b 1 )
echo.
echo Done. Press the Windows key and type MONO to open it.
echo Right-click it there and choose Pin to taskbar if you like.
echo Keep this folder where it is. If you move it, run this file again.
pause
