@echo off
cd /d "%~dp0"
set EXE=%~dp0node_modules\electron\dist\electron.exe
if exist "%EXE%" goto launch

set NODEVER=v20.18.1
set NODEDIR=%~dp0runtime\node-%NODEVER%-win-x64
where node >nul 2>nul
if errorlevel 1 (
  if not exist "%NODEDIR%\node.exe" (
    echo Node.js not found. Downloading a private copy, one time only...
    mkdir runtime 2>nul
    powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest https://nodejs.org/dist/%NODEVER%/node-%NODEVER%-win-x64.zip -OutFile runtime\node.zip; Expand-Archive runtime\node.zip runtime -Force; Remove-Item runtime\node.zip"
    if not exist "%NODEDIR%\node.exe" ( echo Download failed. Check your internet. & pause & exit /b 1 )
  )
  set "PATH=%NODEDIR%;%PATH%"
)
echo First run: installing, this takes a minute...
call npm install --no-audit --no-fund
if not exist "%EXE%" ( echo Install failed. & pause & exit /b 1 )

:launch
start "" "%EXE%" .
exit
