# MONO Launcher (private, personal use)

Black-and-white animated Minecraft: Java Edition launcher for desktop.

- Microsoft sign-in (official), token stored encrypted via OS keychain
- Vanilla or Fabric, any release version
- Built-in mod browser (Modrinth) with automatic required dependencies
- Installed-mods manager, RAM slider, no telemetry

## Run (no terminal)
Install Node.js once, then double-click:
- Windows: Start-MONO.bat (first run), then Add-MONO-to-Apps.bat once to put MONO in your Start menu and on your desktop with its icon
- Mac: Start-MONO.command
- Linux: start-mono.sh

First launch installs dependencies automatically.

## Package for yourself
    npm run dist

Requires Node 18+ and a Java runtime on PATH. Requires a Minecraft Java account you own.
Mods are installed to the launcher's own data folder (use "Open game folder").
