'use strict';
// Extra launcher features that don't need Electron: server ping, crash doctor,
// world backups and storage tools. Kept separate so they can be tested on their own.
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const net = require('net');
const dns = require('dns').promises;
const { execFile } = require('child_process');

function run(cmd, args) {
  return new Promise((res, rej) => execFile(cmd, args, { windowsHide: true, maxBuffer: 1e8 },
    (e, so, se) => e ? rej(new Error(String(se || e.message).trim())) : res(so)));
}

/* ---------- server list ping (Minecraft Server List Ping, no third party) ---------- */
function varInt(n) {
  const out = []; n >>>= 0;
  do { let b = n & 0x7f; n >>>= 7; if (n) b |= 0x80; out.push(b); } while (n);
  return Buffer.from(out);
}
function mcString(s) { const b = Buffer.from(s, 'utf8'); return Buffer.concat([varInt(b.length), b]); }
function readVarInt(buf, off) {
  let r = 0, shift = 0, i = off;
  for (;;) {
    if (i >= buf.length) return null;
    const b = buf[i++];
    r |= (b & 0x7f) << shift;
    if (!(b & 0x80)) break;
    shift += 7;
    if (shift > 35) throw new Error('bad varint');
  }
  return { value: r, next: i };
}
function motdText(d) {
  if (!d) return '';
  if (typeof d === 'string') return d.replace(/§./g, '');
  let s = d.text || '';
  if (Array.isArray(d.extra)) s += d.extra.map(motdText).join('');
  return s.replace(/§./g, '');
}
const ADDR_RE = /^[A-Za-z0-9._-]+(:\d{1,5})?$/;
async function resolveServer(addr) {
  const orig = String(addr).trim();
  if (!ADDR_RE.test(orig)) throw new Error('Bad server address');
  const m = orig.match(/^(.*?):(\d{1,5})$/);
  if (m) return { host: m[1], port: +m[2], orig: m[1] };
  try {
    const srv = await dns.resolveSrv('_minecraft._tcp.' + orig);
    if (srv && srv.length) return { host: srv[0].name, port: srv[0].port, orig };
  } catch {}
  return { host: orig, port: 25565, orig };
}
async function pingServer(addr, timeoutMs = 5000) {
  let t;
  try { t = await resolveServer(addr); } catch { return { online: false }; }
  return new Promise(resolve => {
    const t0 = Date.now();
    const sock = net.connect({ host: t.host, port: t.port });
    sock.setTimeout(timeoutMs);
    let buf = Buffer.alloc(0), done = false;
    const finish = r => { if (done) return; done = true; sock.destroy(); resolve(r); };
    sock.on('connect', () => {
      const hs = Buffer.concat([varInt(0), varInt(765), mcString(t.orig), Buffer.from([t.port >> 8, t.port & 255]), varInt(1)]);
      sock.write(Buffer.concat([varInt(hs.length), hs]));
      sock.write(Buffer.from([1, 0]));
    });
    sock.on('data', d => {
      buf = Buffer.concat([buf, d]);
      try {
        const len = readVarInt(buf, 0);
        if (!len || buf.length < len.next + len.value) return;
        const id = readVarInt(buf, len.next);
        const slen = id && readVarInt(buf, id.next);
        if (!slen || buf.length < slen.next + slen.value) return;
        const j = JSON.parse(buf.slice(slen.next, slen.next + slen.value).toString('utf8'));
        finish({
          online: true,
          ping: Date.now() - t0,
          motd: motdText(j.description).trim(),
          players: j.players || { online: 0, max: 0 },
          version: j.version && j.version.name,
          favicon: typeof j.favicon === 'string' && j.favicon.startsWith('data:image/png') ? j.favicon : null
        });
      } catch {}
    });
    sock.on('timeout', () => finish({ online: false }));
    sock.on('error', () => finish({ online: false }));
    sock.on('close', () => finish({ online: false }));
  });
}

/* ---------- crash doctor ---------- */
const RULES = [
  { re: /OutOfMemoryError|GC overhead limit|Java heap space/i, action: 'ram',
    title: 'Minecraft ran out of memory',
    fix: 'Give it more memory in Settings, or remove heavy mods and shaders.' },
  { re: /UnsupportedClassVersionError|class file version \d+/i,
    title: 'Wrong Java version for a mod or the game',
    fix: 'A mod was built for a newer Java than this Minecraft version uses. Try a newer Minecraft version or an older build of that mod.' },
  { re: /Incompatible mods found|Mod resolution failed|Missing or unsupported mandatory dependencies|requires (?:any )?version/i,
    title: 'A mod is missing a dependency or is the wrong version',
    fix: 'Install the missing mod (often Fabric API) or update or remove the mod that complains.',
    detail: t => t.split(/\r?\n/).map(l => l.trim()).filter(l => /requires|depends on|incompatible|missing/i.test(l) && l.length < 220).slice(0, 4) },
  { re: /Mixin apply failed|MixinTransformerError|InvalidInjectionException|Mixin transformation of/i,
    title: 'Two mods are conflicting (Mixin error)',
    fix: 'Remove the mod you added most recently, or run Check for updates on the Installed page.' },
  { re: /NoSuchMethodError|NoClassDefFoundError|NoSuchFieldError|ClassNotFoundException/i,
    title: 'A mod was built for a different game version',
    fix: 'Make sure every mod matches the Minecraft version and loader chosen on the Play page.' },
  { re: /GLFW error|Pixel format not accelerated|org\.lwjgl\.LWJGLException|GL_OUT_OF_MEMORY/i,
    title: 'Graphics driver problem',
    fix: 'Update your graphics drivers. If you use shaders, turn them off and try again.' },
  { re: /UnknownHostException|SSLHandshakeException|Failed to download/i,
    title: 'Network problem',
    fix: 'Check your internet connection and try again.' }
];
function diagnoseText(text) {
  const findings = [];
  const sus = text.match(/Suspected Mods?:\s*\r?\n([\s\S]*?)\r?\n\s*\r?\n/);
  if (sus) {
    const lines = sus[1].split(/\r?\n/).map(l => l.trim()).filter(l => l && !/^none$/i.test(l)).slice(0, 5);
    if (lines.length) findings.push({ title: 'Mods the crash report points at', fix: 'Try removing or updating these first.', detail: lines });
  }
  for (const r of RULES) {
    if (!r.re.test(text)) continue;
    const f = { title: r.title, fix: r.fix };
    if (r.action) f.action = r.action;
    if (r.detail) { const d = r.detail(text); if (d.length) f.detail = d; }
    findings.push(f);
  }
  return findings.slice(0, 5);
}
async function diagnose(root, since, tail = '') {
  let text = '', report = null;
  try {
    const dir = path.join(root, 'crash-reports');
    let best = 0;
    for (const f of await fsp.readdir(dir)) {
      if (!f.endsWith('.txt')) continue;
      const st = await fsp.stat(path.join(dir, f));
      if (st.mtimeMs >= since - 5000 && st.mtimeMs > best) { best = st.mtimeMs; report = path.join(dir, f); }
    }
    if (report) text += await fsp.readFile(report, 'utf8');
  } catch {}
  try { text += '\n' + (await fsp.readFile(path.join(root, 'logs', 'latest.log'), 'utf8')).slice(-80000); } catch {}
  text += '\n' + tail;
  return { report, findings: diagnoseText(text) };
}

/* ---------- storage ---------- */
async function dirSize(dir) {
  let total = 0, ents;
  try { ents = await fsp.readdir(dir, { withFileTypes: true }); } catch { return 0; }
  for (const e of ents) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) total += await dirSize(p);
    else if (e.isFile()) { try { total += (await fsp.stat(p)).size; } catch {} }
  }
  return total;
}
const AREAS = [
  ['versions', 'Game versions'], ['libraries', 'Libraries'], ['assets', 'Game assets'],
  ['mods', 'Mods'], ['resourcepacks', 'Resource packs'], ['shaderpacks', 'Shaders'],
  ['saves', 'Worlds'], ['backups', 'Backups'], ['screenshots', 'Screenshots'],
  ['logs', 'Logs'], ['crash-reports', 'Crash reports']
];
const storageInfo = root => Promise.all(AREAS.map(async ([d, label]) => ({ key: d, label, size: await dirSize(path.join(root, d)) })));
async function storageClear(root, what) {
  const d = what === 'crash' ? 'crash-reports' : what === 'logs' ? 'logs' : null;
  if (!d) throw new Error('Unknown storage area');
  const dir = path.join(root, d);
  let freed = 0;
  for (const f of await fsp.readdir(dir).catch(() => [])) {
    if (f === 'latest.log') continue;
    const p = path.join(dir, f);
    try { const st = await fsp.stat(p); if (st.isFile()) { await fsp.unlink(p); freed += st.size; } } catch {}
  }
  return freed;
}

/* ---------- worlds and backups ---------- */
const KEEP_BACKUPS = 8;
const BACKUP_RE = /^(.+)__(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})\.tar\.gz$/;
const pad = n => String(n).padStart(2, '0');
function stamp(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}
function safeName(n) {
  const b = path.basename(String(n));
  if (!b || b === '.' || b === '..' || b !== String(n)) throw new Error('Bad name');
  return b;
}
async function listWorlds(root) {
  const saves = path.join(root, 'saves');
  let ents;
  try { ents = await fsp.readdir(saves, { withFileTypes: true }); } catch { return []; }
  const out = [];
  for (const e of ents) {
    if (!e.isDirectory()) continue;
    try {
      const st = await fsp.stat(path.join(saves, e.name, 'level.dat'));
      out.push({ name: e.name, mtime: st.mtimeMs, size: await dirSize(path.join(saves, e.name)) });
    } catch {}
  }
  return out.sort((a, b) => b.mtime - a.mtime);
}
async function listBackups(root) {
  const dir = path.join(root, 'backups');
  const out = [];
  for (const f of await fsp.readdir(dir).catch(() => [])) {
    const m = f.match(BACKUP_RE);
    if (!m) continue;
    const st = await fsp.stat(path.join(dir, f));
    out.push({ file: f, world: m[1], stamp: m[2], size: st.size, mtime: st.mtimeMs });
  }
  return out.sort((a, b) => b.mtime - a.mtime);
}
async function backupWorld(root, name) {
  const world = safeName(name);
  const saves = path.join(root, 'saves');
  await fsp.stat(path.join(saves, world, 'level.dat')); // must be a real world
  const dir = path.join(root, 'backups');
  await fsp.mkdir(dir, { recursive: true });
  const file = `${world}__${stamp()}.tar.gz`;
  await run('tar', ['-czf', path.join(dir, file), '-C', saves, world]);
  const mine = (await listBackups(root)).filter(b => b.world === world);
  for (const old of mine.slice(KEEP_BACKUPS)) await fsp.unlink(path.join(dir, old.file)).catch(() => {});
  return file;
}
async function backupAll(root) {
  let n = 0;
  for (const w of await listWorlds(root)) { try { await backupWorld(root, w.name); n++; } catch {} }
  return n;
}
// back up only worlds changed since their newest backup
async function autoBackup(root) {
  const backups = await listBackups(root);
  let n = 0;
  for (const w of await listWorlds(root)) {
    const last = backups.find(b => b.world === w.name);
    if (last && last.mtime >= w.mtime) continue;
    try { await backupWorld(root, w.name); n++; } catch {}
  }
  return n;
}
async function restoreBackup(root, file) {
  const f = safeName(file);
  const m = f.match(BACKUP_RE);
  if (!m) throw new Error('Not a backup file');
  const saves = path.join(root, 'saves');
  await fsp.mkdir(saves, { recursive: true });
  const target = path.join(saves, m[1]);
  if (fs.existsSync(target)) await fsp.rename(target, path.join(saves, `${m[1]}_before_restore_${stamp()}`));
  await run('tar', ['-xzf', path.join(root, 'backups', f), '-C', saves]);
  return m[1];
}
async function deleteBackup(root, file) {
  const f = safeName(file);
  if (!BACKUP_RE.test(f)) throw new Error('Not a backup file');
  await fsp.unlink(path.join(root, 'backups', f));
  return true;
}

module.exports = {
  resolveServer, pingServer, diagnose, diagnoseText,
  storageInfo, storageClear, dirSize,
  listWorlds, listBackups, backupWorld, backupAll, autoBackup, restoreBackup, deleteBackup
};
