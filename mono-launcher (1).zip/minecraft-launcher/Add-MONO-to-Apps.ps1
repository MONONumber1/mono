$d = Split-Path -Parent $MyInvocation.MyCommand.Path
$w = New-Object -ComObject WScript.Shell
$targets = @(
  (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\MONO.lnk'),
  (Join-Path ([Environment]::GetFolderPath('Desktop')) 'MONO.lnk')
)
foreach ($p in $targets) {
  $s = $w.CreateShortcut($p)
  $s.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
  $s.Arguments = '"' + (Join-Path $d 'Start-MONO.vbs') + '"'
  $s.WorkingDirectory = $d
  $s.IconLocation = (Join-Path $d 'assets\icon.ico')
  $s.Description = 'MONO launcher'
  $s.Save()
}
