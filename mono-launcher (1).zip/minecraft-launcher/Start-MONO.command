#!/bin/sh
cd "$(dirname "$0")" || exit 1
V=v20.18.1
if ! command -v node >/dev/null 2>&1; then
  OS=$(uname -s); ARCH=$(uname -m)
  case "$OS" in Darwin) P=darwin;; *) P=linux;; esac
  case "$ARCH" in arm64|aarch64) A=arm64;; *) A=x64;; esac
  D="runtime/node-$V-$P-$A"
  if [ ! -x "$D/bin/node" ]; then
    echo "Node.js not found. Downloading a private copy, one time only..."
    mkdir -p runtime
    curl -fL "https://nodejs.org/dist/$V/node-$V-$P-$A.tar.gz" | tar -xz -C runtime || { echo "Download failed."; exit 1; }
  fi
  PATH="$PWD/$D/bin:$PATH"; export PATH
fi
[ -d node_modules ] || npm install --no-audit --no-fund || exit 1
nohup npm start >/dev/null 2>&1 &
