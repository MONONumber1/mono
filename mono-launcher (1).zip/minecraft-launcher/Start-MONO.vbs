' Double-click this after the first setup: opens the launcher with no black window.
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
exe = dir & "\node_modules\electron\dist\electron.exe"
sh.CurrentDirectory = dir
If fso.FileExists(exe) Then
  sh.Run """" & exe & """ .", 1, False
Else
  sh.Run """" & dir & "\Start-MONO.bat""", 1, False
End If
