const { app, BrowserWindow, ipcMain, shell, safeStorage, dialog, nativeImage, clipboard } = require('electron');
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const { execFile, spawn } = require('child_process');
const { Client } = require('minecraft-launcher-core');
const { Auth } = require('msmc');
const extras = require('./extras');

const UA = 'MonoLauncher/1.0 (private personal use)';
const DATA = app.getPath('userData');
const ROOT = path.join(DATA, 'minecraft');
const MODS = path.join(ROOT, 'mods');
const SETTINGS = path.join(DATA, 'settings.json');
const AUTHFILE = path.join(DATA, 'auth.bin');

let win;
let xbox = null; // msmc Xbox manager
let profile = null; // { name, uuid }
const authManager = new Auth('select_account');

/* ---------- helpers ---------- */
async function getJSON(url) {
  const r = await fetch(url, { headers: { 'User-Agent': UA } });
  if (!r.ok) throw new Error(`${r.status} ${r.statusText} for ${url}`);
  return r.json();
}
async function loadSettings() {
  try { return JSON.parse(await fsp.readFile(SETTINGS, 'utf8')); }
  catch { return { ram: 4, version: '', loader: 'vanilla' }; }
}
async function saveSettings(s) { await fsp.writeFile(SETTINGS, JSON.stringify(s, null, 2)); }
function send(ch, data) { if (win && !win.isDestroyed()) win.webContents.send(ch, data); }
async function saveAuth() {
  if (!xbox || !safeStorage.isEncryptionAvailable()) return;
  await fsp.writeFile(AUTHFILE, safeStorage.encryptString(xbox.save()));
}
async function restoreAuth() {
  try {
    if (!safeStorage.isEncryptionAvailable()) return;
    const saved = safeStorage.decryptString(await fsp.readFile(AUTHFILE));
    xbox = await authManager.refresh(saved);
    const mc = await xbox.getMinecraft();
    profile = { name: mc.profile.name, uuid: mc.profile.id };
  } catch { xbox = null; profile = null; }
}
async function download(url, dest) {
  const r = await fetch(url, { headers: { 'User-Agent': UA } });
  if (!r.ok) throw new Error(`Download failed: ${r.status}`);
  await fsp.mkdir(path.dirname(dest), { recursive: true });
  await fsp.writeFile(dest, Buffer.from(await r.arrayBuffer()));
}

/* ---------- window ---------- */
function createWindow() {
  win = new BrowserWindow({
    width: 1100, height: 700, minWidth: 900, minHeight: 600,
    backgroundColor: '#000000', title: 'MONO', icon: path.join(__dirname, 'assets', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
}
app.whenReady().then(async () => {
  for (const k of Object.values(KINDS)) await fsp.mkdir(path.join(ROOT, k.dir), { recursive: true });
  await restoreAuth();
  createWindow();
});
app.on('window-all-closed', () => app.quit());

/* ---------- IPC ---------- */
ipcMain.handle('state', async () => ({ profile, settings: await loadSettings() }));

ipcMain.handle('settings:save', async (_e, s) => { await saveSettings(s); return true; });

ipcMain.handle('login', async () => {
  xbox = await authManager.launch('electron');
  const mc = await xbox.getMinecraft();
  profile = { name: mc.profile.name, uuid: mc.profile.id };
  await saveAuth();
  return profile;
});

ipcMain.handle('logout', async () => {
  xbox = null; profile = null;
  try { await fsp.unlink(AUTHFILE); } catch {}
  return true;
});

ipcMain.handle('versions', async () => {
  const m = await getJSON('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
  return m.versions.filter(v => v.type === 'release').map(v => v.id);
});

ipcMain.handle('open-folder', () => shell.openPath(ROOT));
ipcMain.handle('open-optifine', () => shell.openExternal('https://optifine.net/downloads'));


/* ---------- managed Java (auto-download, one time per major version) ---------- */
const JAVA_DIR = path.join(DATA, 'java');
function run(cmd, args) {
  return new Promise((res, rej) => execFile(cmd, args, { windowsHide: true, maxBuffer: 1e8 },
    (e, so, se) => e ? rej(new Error(se || e.message)) : res(so)));
}
async function findJavaBin(dir, depth = 0) {
  const exe = process.platform === 'win32' ? 'java.exe' : 'java';
  try {
    const bin = path.join(dir, 'bin', exe);
    if (fs.existsSync(bin)) return bin;
    if (depth > 4) return null;
    for (const e of await fsp.readdir(dir, { withFileTypes: true })) {
      if (e.isDirectory()) {
        const r = await findJavaBin(path.join(dir, e.name), depth + 1);
        if (r) return r;
      }
    }
  } catch {}
  return null;
}
async function neededJava(mcVersion) {
  try {
    const m = await getJSON('https://piston-meta.mojang.com/mc/game/version_manifest_v2.json');
    const v = m.versions.find(x => x.id === mcVersion);
    if (!v) return 21;
    const j = await getJSON(v.url);
    return (j.javaVersion && j.javaVersion.majorVersion) || 8;
  } catch { return 21; }
}
async function ensureJava(mcVersion) {
  const major = await neededJava(mcVersion);
  const dir = path.join(JAVA_DIR, String(major));
  let bin = await findJavaBin(dir);
  if (bin) return bin;
  send('log', `Downloading Java ${major} (one time only)…`);
  const os = { win32: 'windows', darwin: 'mac', linux: 'linux' }[process.platform];
  const arch = process.arch === 'arm64' ? 'aarch64' : 'x64';
  const url = `https://api.adoptium.net/v3/binary/latest/${major}/ga/${os}/${arch}/jre/hotspot/normal/eclipse`;
  const file = path.join(JAVA_DIR, `jre-${major}${process.platform === 'win32' ? '.zip' : '.tar.gz'}`);
  await download(url, file);
  await fsp.mkdir(dir, { recursive: true });
  send('log', 'Unpacking Java…');
  await run('tar', ['-xf', file, '-C', dir]);
  await fsp.unlink(file).catch(() => {});
  bin = await findJavaBin(dir);
  if (!bin) throw new Error('Java install failed.');
  if (process.platform !== 'win32') await fsp.chmod(bin, 0o755).catch(() => {});
  return bin;
}

/* ---------- Forge ---------- */
function runStreaming(cmd, args) {
  return new Promise((res, rej) => {
    const c = spawn(cmd, args, { windowsHide: true, cwd: ROOT });
    const out = d => String(d).split(/\r?\n/).filter(Boolean).forEach(l => send('log', l));
    c.stdout.on('data', out); c.stderr.on('data', out);
    c.on('error', rej);
    c.on('close', code => code === 0 ? res() : rej(new Error(`Forge installer exited with code ${code}`)));
  });
}
async function prepareForge(mcVersion, javaBin) {
  const promos = (await getJSON('https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json')).promos;
  const fv = promos[`${mcVersion}-recommended`] || promos[`${mcVersion}-latest`];
  if (!fv) throw new Error(`Forge isn't available for ${mcVersion}. Pick another version.`);
  const versionsDir = path.join(ROOT, 'versions');
  const findInstalled = async () => {
    try {
      return (await fsp.readdir(versionsDir)).find(n => {
        const l = n.toLowerCase();
        return l.startsWith(mcVersion.toLowerCase() + '-forge') && n.includes(fv);
      });
    } catch { return undefined; }
  };
  let id = await findInstalled();
  if (id) return id;
  send('log', `Installing Forge ${fv} (one time only, takes a few minutes)…`);
  const jarName = `forge-${mcVersion}-${fv}-installer.jar`;
  const jar = path.join(ROOT, 'forge', jarName);
  await download(`https://maven.minecraftforge.net/net/minecraftforge/forge/${mcVersion}-${fv}/${jarName}`, jar);
  const prof = path.join(ROOT, 'launcher_profiles.json');
  if (!fs.existsSync(prof)) await fsp.writeFile(prof, JSON.stringify({ profiles: {}, selectedProfile: '' }));
  await runStreaming(javaBin, ['-jar', jar, '--installClient', ROOT]);
  id = await findInstalled();
  if (!id) throw new Error('Forge install did not finish. Check the log.');
  return id;
}

/* ---------- launching ---------- */
async function prepareFabric(mcVersion) {
  const loaders = await getJSON(`https://meta.fabricmc.net/v2/versions/loader/${mcVersion}`);
  if (!loaders.length) throw new Error(`Fabric does not support ${mcVersion}`);
  const loaderVer = loaders[0].loader.version;
  const id = `fabric-loader-${loaderVer}-${mcVersion}`;
  const dir = path.join(ROOT, 'versions', id);
  const json = path.join(dir, `${id}.json`);
  if (!fs.existsSync(json)) {
    const prof = await getJSON(`https://meta.fabricmc.net/v2/versions/loader/${mcVersion}/${loaderVer}/profile/json`);
    await fsp.mkdir(dir, { recursive: true });
    await fsp.writeFile(json, JSON.stringify(prof));
  }
  return id;
}

const JVM_PRESETS = {
  smooth: ['-XX:+UseG1GC', '-XX:+ParallelRefProcEnabled', '-XX:MaxGCPauseMillis=200', '-XX:+UnlockExperimentalVMOptions',
    '-XX:+DisableExplicitGC', '-XX:G1NewSizePercent=30', '-XX:G1MaxNewSizePercent=40', '-XX:G1HeapRegionSize=8M',
    '-XX:G1ReservePercent=20', '-XX:G1HeapWastePercent=5', '-XX:G1MixedGCCountTarget=4',
    '-XX:InitiatingHeapOccupancyPercent=15', '-XX:G1MixedGCLiveThresholdPercent=90',
    '-XX:G1RSetUpdatingPauseTimePercent=5', '-XX:SurvivorRatio=32', '-XX:+PerfDisableSharedMem', '-XX:MaxTenuringThreshold=1'],
  lowend: ['-XX:+UseSerialGC', '-XX:MinHeapFreeRatio=10', '-XX:MaxHeapFreeRatio=30']
};

/* ---------- play stats ---------- */
const STATS = path.join(DATA, 'stats.json');
async function readStats() {
  try { return JSON.parse(await fsp.readFile(STATS, 'utf8')); } catch { return { sessions: [] }; }
}
async function addSession(sess) {
  const st = await readStats();
  st.sessions.push(sess);
  st.sessions = st.sessions.slice(-1000);
  await fsp.writeFile(STATS, JSON.stringify(st));
}
ipcMain.handle('stats', readStats);

let lastReport = null;
ipcMain.handle('launch', async (_e, { version, loader, ram, server }) => {
  if (!xbox) throw new Error('Sign in with Microsoft first.');
  const st = await loadSettings();
  const mc = await xbox.getMinecraft();
  const launcher = new Client();
  const version_opt = { number: version, type: 'release' };
  const javaPath = await ensureJava(version);
  if (st.autoBackup) {
    try {
      send('log', 'Backing up worlds…');
      const n = await extras.autoBackup(ROOT);
      send('log', n ? `Backed up ${n} world${n > 1 ? 's' : ''}.` : 'Worlds already backed up.');
    } catch (e) { send('log', 'Backup skipped: ' + e.message); }
  }
  if (loader === 'fabric') {
    send('log', 'Preparing Fabric…');
    version_opt.custom = await prepareFabric(version);
  }
  if (loader === 'forge' || loader === 'optifine') {
    if (loader === 'optifine') {
      const jars = await listKind('mod');
      if (!jars.some(f => /optifine/i.test(f))) {
        throw new Error('OptiFine not found. Download it from optifine.net, then go to Installed → Mods → Import file… and pick the OptiFine .jar.');
      }
    }
    send('log', 'Preparing Forge…');
    version_opt.custom = await prepareForge(version, javaPath);
  }

  if (st.autoFps && FPS_MODS[loader] && !(await fpsMarked(version, loader))) {
    try {
      send('log', 'Installing FPS mods (first launch of this version)…');
      const r = await installFps(version, loader);
      if (r.added.length) await markFps(version, loader);
      send('log', `FPS mods ready: ${r.added.join(', ') || 'none available for this version'}.`);
    } catch (e) { send('log', 'FPS mods skipped: ' + e.message); }
  }

  const tail = [];
  const keep = m => { String(m).split(/\r?\n/).forEach(l => tail.push(l)); while (tail.length > 400) tail.shift(); };
  launcher.on('debug', m => { send('log', m); keep(m); });
  launcher.on('data', m => { send('log', String(m).trimEnd()); keep(m); });
  launcher.on('progress', p => send('progress', { type: p.type, task: p.task, total: p.total }));
  launcher.on('package-extract', () => send('log', 'Extracting natives…'));
  const began = Date.now();
  launcher.on('close', async code => {
    const ended = Date.now();
    if (ended - began > 10000) addSession({ s: began, e: ended, v: version, l: loader }).catch(() => {});
    if (st.hideOnPlay && win && !win.isDestroyed()) { win.restore(); win.focus(); }
    send('closed', code);
    if (code !== 0) {
      try {
        const r = await extras.diagnose(ROOT, began, tail.join('\n'));
        lastReport = r.report;
        send('crash', { code, findings: r.findings, hasReport: !!r.report });
      } catch {}
    }
  });

  const args = [...(JVM_PRESETS[st.jvm] || []), ...String(st.customArgs || '').split(/\s+/).filter(Boolean)];
  const opts = {
    authorization: mc.mclc(),
    javaPath,
    root: ROOT,
    version: version_opt,
    memory: { max: `${ram}G`, min: '1G' }
  };
  if (args.length) opts.customArgs = args;
  if (st.fullscreen) opts.window = { fullscreen: true };
  else if (+st.winW > 0 && +st.winH > 0) opts.window = { width: +st.winW, height: +st.winH };
  if (server) {
    const t = await extras.resolveServer(server);
    if (+String(version).split('.')[1] >= 20) opts.customLaunchArgs = ['--quickPlayMultiplayer', `${t.host}:${t.port}`];
    else opts.server = { host: t.host, port: String(t.port) };
  }
  const child = await launcher.launch(opts);
  if (!child) throw new Error('Launch failed. Check the log.');
  send('started', true);
  if (st.hideOnPlay && win && !win.isDestroyed()) win.minimize();
  return true;
});

/* ---------- content: mods, resource packs, shaders (Modrinth + import) ---------- */
const crypto = require('crypto');
const KINDS = {
  mod:          { dir: 'mods',          ext: ['.jar'], facet: 'mod',          label: 'Mods' },
  resourcepack: { dir: 'resourcepacks', ext: ['.zip'], facet: 'resourcepack', label: 'Resource packs' },
  shader:       { dir: 'shaderpacks',   ext: ['.zip'], facet: 'shader',       label: 'Shaders' }
};
// OptiFine runs on Forge, so it uses Forge mods
function loaderFacet(loader) { return loader === 'fabric' ? 'fabric' : (loader === 'forge' || loader === 'optifine') ? 'forge' : null; }
function kindOf(kind) { const k = KINDS[kind]; if (!k) throw new Error('Unknown type'); return k; }
function kindDir(kind) { return path.join(ROOT, kindOf(kind).dir); }
async function listKind(kind) {
  const dir = kindDir(kind);
  await fsp.mkdir(dir, { recursive: true });
  const exts = kindOf(kind).ext;
  return (await fsp.readdir(dir)).filter(f => exts.includes(path.extname(f).toLowerCase()));
}

ipcMain.handle('content:search', async (_e, { kind, query, version, loader, offset }) => {
  const k = kindOf(kind);
  const facets = [[`project_type:${k.facet}`]];
  if (version) facets.push([`versions:${version}`]);
  if (kind === 'mod' && loaderFacet(loader)) facets.push([`categories:${loaderFacet(loader)}`]);
  const off = Math.max(0, +offset || 0);
  const url = `https://api.modrinth.com/v2/search?limit=20&offset=${off}&query=${encodeURIComponent(query || '')}&facets=${encodeURIComponent(JSON.stringify(facets))}`;
  const data = await getJSON(url);
  return {
    total: data.total_hits,
    hits: data.hits.map(h => ({
      id: h.project_id, slug: h.slug, title: h.title, description: h.description,
      icon: h.icon_url, downloads: h.downloads, author: h.author
    }))
  };
});

async function installProject(projectId, kind, version, loader, seen, installed) {
  if (seen.has(projectId)) return;
  seen.add(projectId);
  const dir = kindDir(kind);
  const base = `https://api.modrinth.com/v2/project/${projectId}/version`;
  const q = new URLSearchParams({ game_versions: JSON.stringify([version]) });
  if (kind === 'mod' && loaderFacet(loader)) q.set('loaders', JSON.stringify([loaderFacet(loader)]));
  let versions = await getJSON(`${base}?${q}`);
  // resource packs and shaders are usually fine across versions, so fall back to the newest file
  if (!versions.length && kind !== 'mod') versions = await getJSON(base);
  if (!versions.length) throw new Error(`No compatible file for ${version}${kind === 'mod' ? ` (${loader})` : ''}.`);
  const v = versions[0];
  const file = v.files.find(f => f.primary) || v.files[0];
  const name = path.basename(file.filename);
  const dest = path.join(dir, name);
  if (!fs.existsSync(dest)) await download(file.url, dest); // already have this exact file
  installed.push(name);
  if (kind === 'mod') {
    for (const dep of v.dependencies || []) {
      if (dep.dependency_type === 'required' && dep.project_id) {
        await installProject(dep.project_id, kind, version, loader, seen, installed);
      }
    }
  }
}

ipcMain.handle('content:install', async (_e, { id, kind, version, loader }) => {
  const installed = [];
  await installProject(id, kind, version, loader, new Set(), installed);
  return installed;
});

ipcMain.handle('content:list', async (_e, kind) => listKind(kind));

ipcMain.handle('content:remove', async (_e, { kind, name }) => {
  const file = path.join(kindDir(kind), path.basename(name));
  let last;
  for (let i = 0; i < 4; i++) {            // Windows can hold a file for a moment (antivirus, game just closed)
    try { await fsp.rm(file, { force: true }); return true; }
    catch (e) { last = e; await new Promise(r => setTimeout(r, 250)); }
  }
  try { await shell.trashItem(file); return true; } catch {}
  if (last && ['EBUSY', 'EPERM', 'EACCES'].includes(last.code)) throw new Error('Windows says this file is in use. Close Minecraft (and anything else using it), then try again.');
  throw new Error('Could not remove it: ' + (last && last.message || 'unknown error'));
});

ipcMain.handle('content:import', async (_e, kind) => {
  const k = kindOf(kind);
  const res = await dialog.showOpenDialog(win, {
    title: `Import ${k.label.toLowerCase()}`,
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: k.label, extensions: k.ext.map(e => e.slice(1)) }]
  });
  if (res.canceled) return [];
  const dir = kindDir(kind);
  await fsp.mkdir(dir, { recursive: true });
  const done = [];
  for (const src of res.filePaths) {
    if (!k.ext.includes(path.extname(src).toLowerCase())) continue;
    const name = path.basename(src);
    await fsp.copyFile(src, path.join(dir, name));
    done.push(name);
  }
  return done;
});

const hashCache = new Map();
function sha1File(file) {
  return new Promise((res, rej) => {
    const h = crypto.createHash('sha1');
    fs.createReadStream(file).on('data', d => h.update(d)).on('end', () => res(h.digest('hex'))).on('error', rej);
  });
}
// icons and names for the Installed page: Modrinth first, then the icon inside the file itself
const detailCache = new Map(); // hash -> { id, title, icon }
const dataUrl = buf => 'data:image/png;base64,' + buf.toString('base64');
function tarGet(archive, entry) {
  return new Promise(res => execFile('tar', ['-xOf', archive, entry],
    { encoding: 'buffer', maxBuffer: 8e6, windowsHide: true },
    (e, so) => res(e || !so || !so.length ? null : so)));
}
async function embeddedIcon(kind, full) {
  try {
    if (kind === 'mod') {
      const meta = await tarGet(full, 'fabric.mod.json');
      if (meta) {
        const j = JSON.parse(meta.toString('utf8'));
        let ic = j.icon;
        if (ic && typeof ic === 'object') { const k = Object.keys(ic).map(Number).sort((a, b) => b - a)[0]; ic = ic[k]; }
        if (typeof ic === 'string') { const b = await tarGet(full, ic.replace(/^\/+/, '')); if (b) return dataUrl(b); }
      }
    }
    const pack = await tarGet(full, 'pack.png');
    if (pack) return dataUrl(pack);
  } catch {}
  return null;
}
ipcMain.handle('content:details', async (_e, kind) => {
  const dir = kindDir(kind);
  const files = await listKind(kind);
  const rows = [];
  for (const f of files) {
    const full = path.join(dir, f);
    const st = await fsp.stat(full);
    const key = `${full}|${st.size}|${st.mtimeMs}`;
    if (!hashCache.has(key)) hashCache.set(key, await sha1File(full));
    rows.push({ file: f, full, hash: hashCache.get(key) });
  }
  const need = rows.filter(r => !detailCache.has(r.hash));
  if (need.length) {
    let vmap = {}, ok = false;
    try {
      const r = await fetch('https://api.modrinth.com/v2/version_files', {
        method: 'POST',
        headers: { 'User-Agent': UA, 'Content-Type': 'application/json' },
        body: JSON.stringify({ hashes: need.map(n => n.hash), algorithm: 'sha1' })
      });
      if (r.ok) { vmap = await r.json(); ok = true; }
    } catch {}
    const ids = [...new Set(Object.values(vmap).map(v => v.project_id))];
    const projects = {};
    for (let i = 0; i < ids.length; i += 40) {
      try {
        const list = await getJSON(`https://api.modrinth.com/v2/projects?ids=${encodeURIComponent(JSON.stringify(ids.slice(i, i + 40)))}`);
        list.forEach(p => { projects[p.id] = p; });
      } catch { ok = false; }
    }
    for (const n of need) {
      const v = vmap[n.hash];
      const p = v && projects[v.project_id];
      const icon = (p && p.icon_url) || await embeddedIcon(kind, n.full);
      const info = { id: v ? v.project_id : null, title: p ? p.title : null, icon };
      if (ok) detailCache.set(n.hash, info); else n.tmp = info;
      n.info = info;
    }
  }
  return rows.map(r => ({ file: r.file, ...(detailCache.get(r.hash) || r.info || {}) }));
});

// which Modrinth projects are already installed (matched by file hash, so older installs count too)
ipcMain.handle('content:installedIds', async (_e, kind) => {
  try {
    const dir = kindDir(kind);
    const files = await listKind(kind);
    if (!files.length) return [];
    const hashes = [];
    for (const f of files) {
      const full = path.join(dir, f);
      const st = await fsp.stat(full);
      const key = `${full}|${st.size}|${st.mtimeMs}`;
      if (!hashCache.has(key)) hashCache.set(key, await sha1File(full));
      hashes.push(hashCache.get(key));
    }
    const r = await fetch('https://api.modrinth.com/v2/version_files', {
      method: 'POST',
      headers: { 'User-Agent': UA, 'Content-Type': 'application/json' },
      body: JSON.stringify({ hashes, algorithm: 'sha1' })
    });
    if (!r.ok) return [];
    const data = await r.json();
    return [...new Set(Object.values(data).map(v => v.project_id))];
  } catch { return []; }
});


/* ---------- servers ---------- */
ipcMain.handle('server:ping', (_e, addr) => extras.pingServer(addr));

/* ---------- worlds and backups ---------- */
ipcMain.handle('worlds:list', () => extras.listWorlds(ROOT));
ipcMain.handle('worlds:backup', (_e, name) => extras.backupWorld(ROOT, name));
ipcMain.handle('backups:list', () => extras.listBackups(ROOT));
ipcMain.handle('backups:all', () => extras.backupAll(ROOT));
ipcMain.handle('backups:restore', (_e, file) => extras.restoreBackup(ROOT, file));
ipcMain.handle('backups:delete', (_e, file) => extras.deleteBackup(ROOT, file));
ipcMain.handle('open-saves', () => { fsp.mkdir(path.join(ROOT, 'saves'), { recursive: true }).catch(() => {}); return shell.openPath(path.join(ROOT, 'saves')); });

/* ---------- crash doctor / logs ---------- */
ipcMain.handle('crash:openReport', () => lastReport ? shell.openPath(lastReport) : null);
ipcMain.handle('open-shots', () => { fsp.mkdir(SHOTS, { recursive: true }).catch(() => {}); return shell.openPath(SHOTS); });
ipcMain.handle('open-logs', () => shell.openPath(path.join(ROOT, 'logs')));

/* ---------- storage ---------- */
ipcMain.handle('storage:info', () => extras.storageInfo(ROOT));
ipcMain.handle('storage:clear', (_e, what) => extras.storageClear(ROOT, what));

/* ---------- screenshots ---------- */
const SHOTS = path.join(ROOT, 'screenshots');
const thumbCache = new Map();
const shotPath = name => path.join(SHOTS, path.basename(String(name)));
ipcMain.handle('shots:list', async () => {
  try {
    const files = (await fsp.readdir(SHOTS)).filter(f => /\.(png|jpe?g)$/i.test(f));
    const rows = await Promise.all(files.map(async f => ({ name: f, mtime: (await fsp.stat(path.join(SHOTS, f))).mtimeMs })));
    return rows.sort((a, b) => b.mtime - a.mtime).slice(0, 60);
  } catch { return []; }
});
ipcMain.handle('shots:thumb', async (_e, name) => {
  try {
    const p = shotPath(name);
    const key = p + (await fsp.stat(p)).mtimeMs;
    if (thumbCache.has(key)) return thumbCache.get(key);
    const img = nativeImage.createFromPath(p);
    if (img.isEmpty()) return null;
    const url = 'data:image/jpeg;base64,' + img.resize({ width: 420 }).toJPEG(80).toString('base64');
    thumbCache.set(key, url);
    return url;
  } catch { return null; }
});
ipcMain.handle('shots:open', (_e, name) => shell.openPath(shotPath(name)));
ipcMain.handle('shots:copy', (_e, name) => { clipboard.writeImage(nativeImage.createFromPath(shotPath(name))); return true; });
ipcMain.handle('shots:delete', async (_e, name) => { await fsp.unlink(shotPath(name)); return true; });

/* ---------- player head (skin from Mojang's own servers) ---------- */
ipcMain.handle('profile:skin', async () => {
  if (!profile) return null;
  try {
    const j = await getJSON(`https://sessionserver.mojang.com/session/minecraft/profile/${encodeURIComponent(profile.uuid)}`);
    const prop = (j.properties || []).find(p => p.name === 'textures');
    if (!prop) return null;
    const url = JSON.parse(Buffer.from(prop.value, 'base64').toString('utf8')).textures?.SKIN?.url;
    if (!url || new URL(url).hostname !== 'textures.minecraft.net') return null;
    const r = await fetch(url, { headers: { 'User-Agent': UA } });
    if (!r.ok) return null;
    return 'data:image/png;base64,' + Buffer.from(await r.arrayBuffer()).toString('base64');
  } catch { return null; }
});

/* ---------- update checker + shareable setups ---------- */
async function hashRows(kind) {
  const dir = kindDir(kind);
  const rows = [];
  for (const f of await listKind(kind)) {
    const full = path.join(dir, f);
    const st = await fsp.stat(full);
    const key = `${full}|${st.size}|${st.mtimeMs}`;
    if (!hashCache.has(key)) hashCache.set(key, await sha1File(full));
    rows.push({ file: f, hash: hashCache.get(key) });
  }
  return rows;
}
async function modrinthPost(endpoint, body) {
  const r = await fetch(`https://api.modrinth.com/v2/${endpoint}`, {
    method: 'POST',
    headers: { 'User-Agent': UA, 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw new Error('Could not reach Modrinth.');
  return r.json();
}

const pendingUpdates = {};
ipcMain.handle('content:checkUpdates', async (_e, { kind, version, loader }) => {
  const lf = kind === 'mod' ? loaderFacet(loader) : null;
  if (kind === 'mod' && !lf) throw new Error('Pick Fabric, Forge or OptiFine on the Play page first, so I know which mod builds to look for.');
  const rows = await hashRows(kind);
  if (!rows.length) return [];
  const body = { hashes: rows.map(r => r.hash), algorithm: 'sha1' };
  if (version) body.game_versions = [version];
  if (lf) body.loaders = [lf];
  const map = await modrinthPost('version_files/update', body);
  const ups = [];
  for (const row of rows) {
    const v = map[row.hash];
    if (!v) continue;
    if (v.files.some(f => f.hashes && f.hashes.sha1 === row.hash)) continue; // already the newest
    const file = v.files.find(f => f.primary) || v.files[0];
    ups.push({ file: row.file, name: path.basename(file.filename), ver: v.version_number, url: file.url });
  }
  pendingUpdates[kind] = ups;
  return ups.map(({ file, ver }) => ({ file, ver }));
});

ipcMain.handle('content:applyUpdates', async (_e, { kind, files }) => {
  const dir = kindDir(kind);
  let n = 0;
  for (const u of pendingUpdates[kind] || []) {
    if (!files.includes(u.file)) continue;
    await download(u.url, path.join(dir, u.name));
    if (u.name !== u.file) await fsp.unlink(path.join(dir, path.basename(u.file))).catch(() => {});
    n++;
  }
  pendingUpdates[kind] = [];
  return n;
});

const LOADERS = ['vanilla', 'fabric', 'forge', 'optifine'];
ipcMain.handle('pack:export', async (_e, { version, loader }) => {
  const res = await dialog.showSaveDialog(win, {
    title: 'Export setup', defaultPath: 'my-setup.monopack',
    filters: [{ name: 'MONO setup', extensions: ['monopack'] }]
  });
  if (res.canceled || !res.filePath) return null;
  const out = { format: 'monopack', v: 1, version, loader, projects: { mod: [], resourcepack: [], shader: [] } };
  let count = 0, skipped = 0;
  for (const kind of Object.keys(KINDS)) {
    const rows = await hashRows(kind);
    if (!rows.length) continue;
    const map = await modrinthPost('version_files', { hashes: rows.map(r => r.hash), algorithm: 'sha1' });
    for (const row of rows) {
      const v = map[row.hash];
      if (!v) { skipped++; continue; }
      if (!out.projects[kind].includes(v.project_id)) { out.projects[kind].push(v.project_id); count++; }
    }
  }
  await fsp.writeFile(res.filePath, JSON.stringify(out, null, 2));
  return { count, skipped };
});

ipcMain.handle('pack:import', async () => {
  const res = await dialog.showOpenDialog(win, {
    title: 'Import setup', properties: ['openFile'],
    filters: [{ name: 'MONO setup', extensions: ['monopack'] }]
  });
  if (res.canceled || !res.filePaths.length) return null;
  let data;
  try { data = JSON.parse(await fsp.readFile(res.filePaths[0], 'utf8')); } catch { data = null; }
  const idOk = x => typeof x === 'string' && /^[A-Za-z0-9]{6,12}$/.test(x);
  if (!data || data.format !== 'monopack' || typeof data.version !== 'string' || !/^[\w.\-]{1,32}$/.test(data.version) ||
      !LOADERS.includes(data.loader) || !data.projects || typeof data.projects !== 'object') {
    throw new Error('That is not a valid MONO setup file.');
  }
  const jobs = [];
  for (const kind of Object.keys(KINDS)) {
    const list = Array.isArray(data.projects[kind]) ? data.projects[kind] : [];
    for (const id of list) if (idOk(id)) jobs.push({ kind, id });
  }
  if (jobs.length > 300) throw new Error('That setup file is too large.');
  const seen = new Set(), installed = [];
  let done = 0, failed = 0;
  for (const j of jobs) {
    try { await installProject(j.id, j.kind, data.version, data.loader, seen, installed); } catch { failed++; }
    send('pack-progress', { done: ++done, total: jobs.length });
  }
  return { version: data.version, loader: data.loader, installed: installed.length, failed };
});


/* ---------- FPS boost mods ---------- */
// Modrinth project slugs. Sodium/Embeddium are left out for OptiFine since they replace it.
const FPS_MODS = {
  fabric: ['sodium', 'lithium', 'ferrite-core', 'immediatelyfast', 'entityculling', 'modernfix', 'dynamic-fps', 'moreculling', 'memoryleakfix', 'sodium-extra'],
  forge: ['embeddium', 'ferrite-core', 'modernfix', 'immediatelyfast', 'entityculling', 'dynamic-fps', 'memoryleakfix'],
  optifine: ['ferrite-core', 'modernfix', 'entityculling', 'dynamic-fps', 'memoryleakfix']
};
const FPS_DONE = path.join(DATA, 'fps.json');
async function readFps() { try { return JSON.parse(await fsp.readFile(FPS_DONE, 'utf8')); } catch { return {}; } }
async function fpsMarked(version, loader) { return !!(await readFps())[`${version}|${loader}`]; }
async function markFps(version, loader) {
  const d = await readFps();
  d[`${version}|${loader}`] = true;
  await fsp.writeFile(FPS_DONE, JSON.stringify(d));
}
async function installFps(version, loader, onProgress) {
  const list = FPS_MODS[loader];
  if (!list) throw new Error('Pick Fabric, Forge or OptiFine on the Play page first. Vanilla can\'t run mods.');
  const seen = new Set(), files = [], added = [], skipped = [];
  for (let i = 0; i < list.length; i++) {
    try {
      const p = await getJSON(`https://api.modrinth.com/v2/project/${list[i]}`);
      await installProject(p.id, 'mod', version, loader, seen, files);
      added.push(p.title);
    } catch { skipped.push(list[i]); }
    if (onProgress) onProgress(i + 1, list.length);
  }
  return { added, skipped };
}
ipcMain.handle('fps:install', async (_e, { version, loader }) => {
  const r = await installFps(version, loader, (done, total) => send('pack-progress', { done, total }));
  if (r.added.length) await markFps(version, loader);
  return r;
});
