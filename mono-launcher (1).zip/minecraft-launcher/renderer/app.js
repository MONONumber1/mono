const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let state = { profile: null, settings: { ram: 4, version: '', loader: 'vanilla' } };
let launching = false;

/* ---------- themes ---------- */
let FG = '255,255,255'; // foreground colour for the canvas background
let FX = 'network'; // current background effect
const THEMES = [
  { id: 'mono',     name: 'Black',        fx: 'network', bg: '#000000', fg: '#ffffff' },
  { id: 'light',    name: 'White',        fx: 'network', bg: '#f4f4f4', fg: '#0a0a0a' },
  { id: 'midnight', name: 'Midnight',     fx: 'network', bg: '#05070f', fg: '#7fb2ff' },
  { id: 'crimson',  name: 'Crimson',      fx: 'network', bg: '#0a0405', fg: '#ff4d5e' },
  { id: 'forest',   name: 'Forest',       fx: 'network', bg: '#040a06', fg: '#5dff9a' },
  { id: 'violet',   name: 'Violet',       fx: 'network', bg: '#07040d', fg: '#b78bff' },
  { id: 'cherry',   name: 'Cherry Grove', fx: 'petals',  bg: 'linear-gradient(165deg,#3a1226,#10060c)', fg: '#ffb7d1' },
  { id: 'nether',   name: 'Nether',       fx: 'embers',  bg: 'linear-gradient(0deg,#7a1a00,#0c0201)',   fg: '#ff8a3d' },
  { id: 'end',      name: 'The End',      fx: 'stars',   bg: 'linear-gradient(160deg,#2c1858,#05030c)', fg: '#d6b0ff' },
  { id: 'snow',     name: 'Snowy',        fx: 'snow',    bg: 'linear-gradient(180deg,#16283a,#08111a)', fg: '#e4f3ff' },
  { id: 'ocean',    name: 'Ocean',        fx: 'bubbles', bg: 'linear-gradient(180deg,#0a4560,#020f18)', fg: '#62e6e0' }
];
function applyTheme(id) {
  if (!THEMES.some(t => t.id === id)) id = 'mono';
  document.documentElement.dataset.theme = id;
  FX = THEMES.find(t => t.id === id).fx;
  FG = getComputedStyle(document.documentElement).getPropertyValue('--fg-rgb').trim() || FG;
  document.querySelectorAll('.swatch').forEach(s => s.classList.toggle('active', s.dataset.theme === id));
  try { localStorage.setItem('mono-theme', id); } catch {}
  if (state && state.settings) state.settings.theme = id;
}
try { applyTheme(localStorage.getItem('mono-theme') || 'mono'); } catch { applyTheme('mono'); }

/* ---------- splash ---------- */
const logo = $('#logo');
'made by Hdte'.split('').forEach((c, i) => {
  const s = document.createElement('span');
  s.textContent = c === ' ' ? '\u00a0' : c;
  s.style.animationDelay = `${0.15 + i * 0.08}s`;
  logo.appendChild(s);
});

/* ---------- animated background (network + biome effects) ---------- */
(function bg() {
  const cv = $('#bg'), ctx = cv.getContext('2d');
  let w = 0, h = 0, cur = null, items = [], t = 0, mx = -999, my = -999;
  const R = (a, b) => a + Math.random() * (b - a);
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const TAU = Math.PI * 2;
  const PETAL = ['255,183,209', '255,205,222', '255,160,195', '255,224,235'];
  const EMBER = ['255,140,40', '255,90,20', '255,190,80', '255,60,10'];
  const ENDC = ['214,176,255', '255,255,255', '160,120,255', '120,255,220'];

  const COUNT = {
    network: () => Math.min(90, Math.floor(w * h / 18000)),
    petals:  () => Math.min(60, Math.floor(w * h / 26000)),
    embers:  () => Math.min(80, Math.floor(w * h / 20000)),
    stars:   () => Math.min(140, Math.floor(w * h / 9000)),
    snow:    () => Math.min(130, Math.floor(w * h / 9000)),
    bubbles: () => Math.min(45, Math.floor(w * h / 30000))
  };
  function make(kind, spread) {
    const p = { x: R(0, w), y: R(0, h), ph: R(0, TAU) };
    switch (kind) {
      case 'network': p.vx = R(-.175, .175); p.vy = R(-.175, .175); break;
      case 'petals':
        if (!spread) p.y = R(-30, -5);
        Object.assign(p, { s: R(5, 11), vy: R(.5, 1.3), vx: R(-.2, .4), rot: R(0, TAU), vr: R(-.03, .03), c: pick(PETAL), a: R(.55, .95) });
        break;
      case 'embers':
        if (!spread) p.y = h + R(5, 30);
        Object.assign(p, { r: R(.8, 2.6), vy: -R(.4, 1.5), c: pick(EMBER), a: R(.4, 1) });
        break;
      case 'stars':
        Object.assign(p, { r: R(.5, 1.9), vx: R(-.06, .06), vy: R(-.12, .02), c: pick(ENDC), tw: R(.01, .04) });
        break;
      case 'snow':
        if (!spread) p.y = -5;
        Object.assign(p, { r: R(.9, 3.2), vy: R(.5, 1.5), vx: R(-.2, .2) });
        break;
      case 'bubbles':
        if (!spread) p.y = h + R(5, 40);
        Object.assign(p, { r: R(2, 9), vy: -R(.25, .9), a: R(.25, .55) });
        break;
    }
    return p;
  }
  const resize = () => { w = cv.width = innerWidth; h = cv.height = innerHeight; cur = null; };
  addEventListener('resize', resize); resize();
  addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; });

  function tick() {
    if (FX !== cur) { cur = FX; const n = (COUNT[cur] || COUNT.network)(); items = Array.from({ length: n }, () => make(cur, true)); }
    t++;
    ctx.clearRect(0, 0, w, h);
    const wind = Math.sin(t / 240) * .5;
    switch (cur) {
      case 'petals':
        for (const p of items) {
          p.y += p.vy; p.x += p.vx + wind * .6 + Math.sin(t / 50 + p.ph) * .35; p.rot += p.vr;
          if (p.y > h + 20 || p.x > w + 30 || p.x < -30) Object.assign(p, make('petals', false));
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
          ctx.fillStyle = `rgba(${p.c},${p.a})`;
          ctx.beginPath(); ctx.ellipse(0, 0, p.s, p.s * .55, 0, 0, TAU); ctx.fill();
          ctx.fillStyle = `rgba(255,255,255,${p.a * .25})`;
          ctx.beginPath(); ctx.ellipse(-p.s * .2, -p.s * .1, p.s * .45, p.s * .2, 0, 0, TAU); ctx.fill();
          ctx.restore();
        }
        break;
      case 'embers':
        ctx.globalCompositeOperation = 'lighter';
        for (const p of items) {
          p.y += p.vy; p.x += Math.sin(t / 40 + p.ph) * .5 + wind * .3;
          if (p.y < -10) Object.assign(p, make('embers', false));
          const a = p.a * (.6 + .4 * Math.sin(t / 6 + p.ph * 3)) * (.3 + .7 * Math.min(1, Math.max(0, p.y / h)));
          const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5);
          g.addColorStop(0, `rgba(${p.c},${a})`); g.addColorStop(1, `rgba(${p.c},0)`);
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 5, 0, TAU); ctx.fill();
        }
        ctx.globalCompositeOperation = 'source-over';
        break;
      case 'stars':
        for (const p of items) {
          p.x += p.vx; p.y += p.vy;
          if (p.x < 0) p.x = w; if (p.x > w) p.x = 0; if (p.y < 0) p.y = h; if (p.y > h) p.y = 0;
          ctx.fillStyle = `rgba(${p.c},${.25 + .75 * Math.abs(Math.sin(t * p.tw + p.ph))})`;
          ctx.fillRect(p.x, p.y, p.r * 1.6, p.r * 1.6);
        }
        break;
      case 'snow':
        for (const p of items) {
          p.y += p.vy; p.x += p.vx + Math.sin(t / 60 + p.ph) * .3 + wind * .5;
          if (p.y > h + 5) Object.assign(p, make('snow', false));
          if (p.x > w + 5) p.x = -5; if (p.x < -5) p.x = w + 5;
          ctx.fillStyle = `rgba(235,246,255,${.35 + p.r / 5})`;
          ctx.fillRect(p.x, p.y, p.r, p.r);
        }
        break;
      case 'bubbles':
        for (const p of items) {
          p.y += p.vy; p.x += Math.sin(t / 45 + p.ph) * .4;
          if (p.y < -15) Object.assign(p, make('bubbles', false));
          ctx.strokeStyle = `rgba(190,255,255,${p.a})`; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.stroke();
          ctx.fillStyle = `rgba(255,255,255,${p.a * .7})`;
          ctx.beginPath(); ctx.arc(p.x - p.r * .35, p.y - p.r * .35, p.r * .2, 0, TAU); ctx.fill();
        }
        break;
      default: // network
        for (const p of items) {
          p.x += p.vx; p.y += p.vy;
          if (p.x < 0 || p.x > w) p.vx *= -1;
          if (p.y < 0 || p.y > h) p.vy *= -1;
          const dx = p.x - mx, dy = p.y - my, d = Math.hypot(dx, dy);
          if (d < 120) { p.x += dx / d * 1.2; p.y += dy / d * 1.2; }
          ctx.fillStyle = `rgb(${FG})`;
          ctx.fillRect(p.x, p.y, 1.5, 1.5);
        }
        for (let i = 0; i < items.length; i++) for (let j = i + 1; j < items.length; j++) {
          const d = Math.hypot(items[i].x - items[j].x, items[i].y - items[j].y);
          if (d < 130) {
            ctx.strokeStyle = `rgba(${FG},${(1 - d / 130) * .35})`;
            ctx.beginPath(); ctx.moveTo(items[i].x, items[i].y); ctx.lineTo(items[j].x, items[j].y); ctx.stroke();
          }
        }
    }
    requestAnimationFrame(tick);
  }
  tick();
})();

/* ---------- helpers ---------- */
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 3200);
}
function log(m) {
  const l = $('#log');
  l.textContent += m + '\n';
  l.scrollTop = l.scrollHeight;
}
function setStatus(s) { $('#status').textContent = s; }
function saveSettings() {
  state.settings = { ...state.settings, ram: +$('#ram').value, version: $('#version').value, loader: $('#loader').value };
  window.api.saveSettings(state.settings);
}
function renderAccount() {
  $('#who').textContent = state.profile ? state.profile.name : 'Not signed in';
  $('#loginBtn').textContent = state.profile ? 'Switch account' : 'Sign in';
  loadHead();
}
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const KIND_LABEL = { mod: 'mods', resourcepack: 'resource packs', shader: 'shaders' };

/* ---------- pages ---------- */
const browsers = {}; // kind -> { reset, mark, isEmpty }
$$('nav button').forEach(b => b.addEventListener('click', () => {
  $$('nav button').forEach(x => x.classList.toggle('active', x === b));
  $$('.tab').forEach(t => t.classList.remove('show'));
  const sec = $('#tab-' + b.dataset.tab);
  sec.classList.add('show');
  if (b.dataset.tab === 'installed') refreshInstalled();
  if (pageHooks[b.dataset.tab]) pageHooks[b.dataset.tab]();
  const br = browsers[sec.dataset.kind];
  if (br) { if (br.isEmpty()) br.search(true); else br.mark(); }
}));

/* ---------- account ---------- */
$('#loginBtn').addEventListener('click', async () => {
  try { state.profile = await window.api.login(); renderAccount(); toast('Signed in as ' + state.profile.name); }
  catch (e) { toast('Sign-in failed: ' + (e.message || e)); }
});
$('#logoutBtn').addEventListener('click', async () => {
  await window.api.logout(); state.profile = null; renderAccount(); toast('Signed out');
});

/* ---------- play ---------- */
function clearBrowsers() { Object.values(browsers).forEach(b => b.reset()); }
$('#ram').addEventListener('input', () => { $('#ramVal').textContent = $('#ram').value; });
$('#ram').addEventListener('change', saveSettings);
$('#version').addEventListener('change', () => { saveSettings(); clearBrowsers(); });
const LOADER_HINT = {
  vanilla: 'Plain Minecraft, no mods.',
  fabric: 'Fabric mods. Add Iris and Sodium for shaders.',
  forge: 'Forge mods. The first launch installs Forge, which takes a few minutes.',
  optifine: 'Runs on Forge with OptiFine. Download OptiFine from optifine.net, then import the .jar on the Installed page (Mods).'
};
function updateLoaderHint() {
  const l = $('#loader').value;
  $('#loaderHint').textContent = LOADER_HINT[l] || '';
  $('#ofBtn').classList.toggle('hidden', l !== 'optifine');
}
$('#ofBtn').addEventListener('click', () => window.api.openOptifine());
$('#loader').addEventListener('change', () => { saveSettings(); clearBrowsers(); updateLoaderHint(); });

async function startGame(server) {
  if (launching) return;
  if (!state.profile) return toast('Sign in with Microsoft first.');
  launching = true;
  $('#playBtn').disabled = true;
  $('#log').textContent = '';
  $('#doctor').classList.add('hidden');
  $('.progress').classList.add('busy');
  setStatus(server ? 'Joining server…' : 'Preparing…');
  saveSettings();
  try {
    await window.api.launch({ version: $('#version').value, loader: $('#loader').value, ram: +$('#ram').value, server });
  } catch (e) {
    toast(e.message || String(e)); setStatus('Error'); log(String(e.message || e));
    launching = false; $('#playBtn').disabled = false; $('.progress').classList.remove('busy');
  }
}
$('#playBtn').addEventListener('click', () => startGame());
window.api.onLog(m => log(m));
window.api.onProgress(p => {
  $('.progress').classList.remove('busy');
  if (p.total) $('#prog').style.width = Math.min(100, (p.task / p.total) * 100) + '%';
  setStatus(`Downloading ${p.type || ''}`);
});
window.api.onStarted(() => { setStatus('Running'); $('.progress').classList.remove('busy'); $('#prog').style.width = '100%'; });
window.api.onClosed(code => {
  launching = false; $('#playBtn').disabled = false; setStatus(`Closed (${code})`); $('#prog').style.width = '0';
});

/* ---------- browse pages: mods, resource packs, shaders ---------- */
function initBrowse(sec) {
  const kind = sec.dataset.kind;
  const q = sec.querySelector('.q');
  const grid = sec.querySelector('.grid');
  const more = sec.querySelector('.more');
  let offset = 0, total = 0, timer, seq = 0;

  async function mark() {
    let have;
    try { have = new Set(await window.api.installedIds(kind)); } catch { return; }
    grid.querySelectorAll('.card').forEach(c => {
      const b = c.querySelector('button');
      if (!b) return;
      if (have.has(c.dataset.id)) { b.textContent = 'Installed'; b.disabled = true; }
      else if (b.textContent === 'Installed') { b.textContent = 'Install'; b.disabled = false; }
    });
  }

  function addCards(hits, base) {
    hits.forEach((h, i) => {
      const el = document.createElement('div');
      el.className = 'card'; el.dataset.id = h.id; el.style.animationDelay = `${i * 40}ms`;
      el.innerHTML = `${h.icon ? `<img src="${esc(h.icon)}" alt="">` : '<div class="ph"></div>'}
        <div class="info"><h3>${esc(h.title)}</h3><p>${esc(h.description)}</p></div>
        <button class="ghost">Install</button>`;
      el.querySelector('button').addEventListener('click', async e => {
        const btn = e.currentTarget; btn.disabled = true; btn.textContent = '…';
        try {
          const done = await window.api.installContent({ id: h.id, kind, version: $('#version').value, loader: $('#loader').value });
          btn.textContent = 'Installed'; toast(`Installed ${done.length} file${done.length > 1 ? 's' : ''}`);
        } catch (err) { btn.textContent = 'Install'; btn.disabled = false; toast(err.message || String(err)); }
      });
      grid.appendChild(el);
    });
  }

  async function search(reset) {
    const my = ++seq;
    if (reset) { offset = 0; grid.innerHTML = '<div class="empty">Searching…</div>'; more.classList.add('hidden'); }
    else { more.disabled = true; more.textContent = 'Loading…'; }
    try {
      const res = await window.api.searchContent({
        kind, query: q.value, version: $('#version').value, loader: $('#loader').value, offset
      });
      if (my !== seq) return;
      if (reset) grid.innerHTML = '';
      if (reset && !res.hits.length) { grid.innerHTML = '<div class="empty">Nothing found.</div>'; return; }
      addCards(res.hits);
      offset += res.hits.length; total = res.total;
      more.classList.toggle('hidden', offset >= total || !res.hits.length);
      more.disabled = false; more.textContent = 'Load more';
      mark();
    } catch (e) {
      if (my !== seq) return;
      if (reset) grid.innerHTML = `<div class="empty">${esc(e.message || e)}</div>`;
      else toast(e.message || String(e));
      more.disabled = false; more.textContent = 'Load more';
    }
  }

  q.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => search(true), 350); });
  more.addEventListener('click', () => search(false));
  browsers[kind] = {
    search, mark,
    reset: () => { seq++; grid.innerHTML = ''; offset = 0; more.classList.add('hidden'); },
    isEmpty: () => !grid.children.length
  };
}
$$('.browse').forEach(initBrowse);

/* ---------- installed page ---------- */
let installedKind = 'mod';
$$('.subtabs button').forEach(b => b.addEventListener('click', () => {
  installedKind = b.dataset.kind;
  $('#instQ').value = '';
  $$('.subtabs button').forEach(x => x.classList.toggle('active', x === b));
  refreshInstalled();
}));
const PAGE_SIZE = 8;
let installedFiles = [], installedInfo = {}, installedPage = 0;
function renderInstalled() {
  const box = $('#installed'), pager = $('#pager'), kind = installedKind;
  box.innerHTML = ''; pager.innerHTML = '';
  const q = ($('#instQ').value || '').trim().toLowerCase();
  const list = q ? installedFiles.filter(f => (f + ' ' + ((installedInfo[f] || {}).title || '')).toLowerCase().includes(q)) : installedFiles;
  const total = list.length;
  if (!installedFiles.length) { box.innerHTML = `<div class="empty">No ${KIND_LABEL[kind]} installed. Use Import file… to add your own.</div>`; return; }
  if (!total) { box.innerHTML = `<div class="empty">No ${KIND_LABEL[kind]} match “${esc($('#instQ').value.trim())}”.</div>`; return; }
  const pages = Math.ceil(total / PAGE_SIZE);
  installedPage = Math.max(0, Math.min(installedPage, pages - 1));
  const from = installedPage * PAGE_SIZE;
  list.slice(from, from + PAGE_SIZE).forEach((f, i) => {
    const el = document.createElement('div');
    el.className = 'card'; el.style.animationDelay = `${i * 40}ms`;
    el.dataset.file = f;
    el.innerHTML = `<div class="ph">${esc(f.charAt(0).toUpperCase())}</div><div class="info"><h3>${esc(f)}</h3></div><button class="ghost">Remove</button>`;
    el.querySelector('button').addEventListener('click', async () => {
      try { await window.api.removeContent({ kind, name: f }); }
      catch (e) { return toast(String(e.message || e).replace(/^Error invoking remote method '[^']*': (Error: )?/, '')); }
      el.style.transition = 'opacity .3s, transform .3s';
      el.style.opacity = 0; el.style.transform = 'translateX(30px)'; setTimeout(() => refreshInstalled(true), 300);
    });
    box.appendChild(el);
  });
  applyInstalledInfo();
  if (pages < 2) return;
  const go = n => { installedPage = n; renderInstalled(); $('#tab-installed').scrollIntoView({ block: 'start' }); };
  const btn = (label, n, opts = {}) => {
    const b = document.createElement('button');
    b.textContent = label;
    if (opts.active) b.classList.add('active');
    if (opts.disabled) b.disabled = true; else b.addEventListener('click', () => go(n));
    pager.appendChild(b);
  };
  btn('‹ Prev', installedPage - 1, { disabled: installedPage === 0 });
  const show = new Set([0, pages - 1, installedPage - 1, installedPage, installedPage + 1]);
  let last = -1;
  for (let n = 0; n < pages; n++) {
    if (!show.has(n)) continue;
    if (n - last > 1) { const d = document.createElement('span'); d.textContent = '…'; pager.appendChild(d); }
    btn(String(n + 1), n, { active: n === installedPage });
    last = n;
  }
  btn('Next ›', installedPage + 1, { disabled: installedPage === pages - 1 });
  const info = document.createElement('em');
  info.textContent = `${from + 1}–${Math.min(total, from + PAGE_SIZE)} of ${total}`;
  pager.appendChild(info);
}
// fill in real icons and names once they're ready
function applyInstalledInfo() {
  const box = $('#installed');
  [...box.children].forEach(el => {
    const r = el.dataset && installedInfo[el.dataset.file];
    if (!r || el.dataset.done) return;
    el.dataset.done = '1';
    if (r.title) {
      el.querySelector('h3').textContent = r.title;
      el.querySelector('.info').insertAdjacentHTML('beforeend', `<p>${esc(el.dataset.file)}</p>`);
    }
    const ph = el.querySelector('.ph');
    if (r.icon && ph) {
      const img = new Image(); img.alt = ''; img.src = r.icon;
      img.onload = () => { if (ph.isConnected) ph.replaceWith(img); };
    }
  });
}
async function refreshInstalled(keepPage) {
  const kind = installedKind;
  if (!keepPage) installedPage = 0;
  const files = await window.api.listContent(kind);
  if (kind !== installedKind) return;
  installedFiles = files; installedInfo = {};
  renderInstalled();
  window.api.contentDetails(kind).then(rows => {
    if (kind !== installedKind) return;
    rows.forEach(r => { installedInfo[r.file] = r; });
    if ($('#instQ').value.trim()) renderInstalled(); else applyInstalledInfo(); // names can be searched too
  }).catch(() => {});
}
$('#instQ').addEventListener('input', () => { installedPage = 0; renderInstalled(); });
$('#importBtn').addEventListener('click', async () => {
  try {
    const done = await window.api.importContent(installedKind);
    if (done.length) { toast(`Imported ${done.length} file${done.length > 1 ? 's' : ''}`); refreshInstalled(); }
  } catch (e) { toast(e.message || String(e)); }
});
$('#folderBtn').addEventListener('click', () => window.api.openFolder());

/* ---------- shared helpers for the new pages ---------- */
const fmtSize = b => b > 1e9 ? (b / 1e9).toFixed(1) + ' GB' : b > 1e6 ? (b / 1e6).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1e3)) + ' KB';
const fmtDur = ms => { const m = Math.round(ms / 60000); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };
const fmtDate = ms => new Date(ms).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
const LOADER_NAME = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', optifine: 'OptiFine' };
function persist() { window.api.saveSettings(state.settings); }
function card(html, i = 0) {
  const el = document.createElement('div');
  el.className = 'card'; el.style.animationDelay = `${Math.min(i, 12) * 40}ms`; el.innerHTML = html;
  return el;
}
const letter = t => esc(String(t || '?').charAt(0).toUpperCase());

/* ---------- player head ---------- */
async function loadHead() {
  const cv = $('#head');
  if (!state.profile) { cv.classList.add('hidden'); return; }
  const url = await window.api.skin().catch(() => null);
  if (!url) return;
  const img = new Image();
  img.onload = () => {
    const c = cv.getContext('2d');
    c.imageSmoothingEnabled = false; c.clearRect(0, 0, 8, 8);
    c.drawImage(img, 8, 8, 8, 8, 0, 0, 8, 8);
    c.drawImage(img, 40, 8, 8, 8, 0, 0, 8, 8);
    cv.classList.remove('hidden');
  };
  img.src = url;
}

/* ---------- crash doctor ---------- */
window.api.onCrash(r => {
  const box = $('#doctor');
  box.classList.remove('hidden');
  box.querySelector('.d-title').textContent = `Minecraft closed unexpectedly (code ${r.code})`;
  const list = box.querySelector('.d-list'); list.innerHTML = '';
  if (!r.findings.length) list.innerHTML = '<div class="d-item"><b>No obvious cause found.</b><span>Open the crash report or check the last lines of the log below.</span></div>';
  r.findings.forEach(f => {
    const d = document.createElement('div'); d.className = 'd-item';
    d.innerHTML = `<b>${esc(f.title)}</b><span>${esc(f.fix)}</span>${f.detail && f.detail.length ? `<pre>${esc(f.detail.join('\n'))}</pre>` : ''}`;
    if (f.action === 'ram') {
      const next = Math.min(16, +$('#ram').value + 2);
      const b = document.createElement('button'); b.className = 'ghost'; b.textContent = `Set memory to ${next} GB`;
      b.onclick = () => { $('#ram').value = next; $('#ramVal').textContent = next; saveSettings(); toast(`Memory set to ${next} GB`); };
      d.appendChild(b);
    }
    list.appendChild(d);
  });
  const btns = box.querySelector('.d-btns'); btns.innerHTML = '';
  const add = (label, fn) => { const b = document.createElement('button'); b.className = 'ghost'; b.textContent = label; b.onclick = fn; btns.appendChild(b); };
  if (r.hasReport) add('Open crash report', () => window.api.openReport());
  add('Open logs folder', () => window.api.openLogs());
  add('Dismiss', () => box.classList.add('hidden'));
});

/* ---------- installed: updates + shareable setups ---------- */
$('#updBtn').addEventListener('click', async () => {
  const box = $('#updates'), kind = installedKind;
  box.innerHTML = '<div class="empty">Checking…</div>';
  try {
    const ups = await window.api.checkUpdates({ kind, version: $('#version').value, loader: $('#loader').value });
    if (!ups.length) { box.innerHTML = ''; return toast('Everything is up to date.'); }
    box.innerHTML = `<div class="u-head"><b>${ups.length} update${ups.length > 1 ? 's' : ''} available</b><button class="ghost" id="updAll">Update all</button></div>` +
      ups.map(u => `<div class="u-row"><span>${esc(u.file)}</span><i>→</i><span>${esc(u.ver)}</span></div>`).join('');
    $('#updAll').onclick = async e => {
      e.currentTarget.disabled = true; e.currentTarget.textContent = 'Updating…';
      try {
        const n = await window.api.applyUpdates({ kind, files: ups.map(u => u.file) });
        box.innerHTML = ''; toast(`Updated ${n} file${n === 1 ? '' : 's'}`); refreshInstalled();
      } catch (err) { toast(err.message || String(err)); }
    };
  } catch (e) { box.innerHTML = ''; toast(e.message || String(e)); }
});
$('#expBtn').addEventListener('click', async () => {
  try {
    const r = await window.api.exportPack({ version: $('#version').value, loader: $('#loader').value });
    if (r) toast(`Saved ${r.count} item${r.count === 1 ? '' : 's'}` + (r.skipped ? ` (${r.skipped} skipped, not on Modrinth)` : ''));
  } catch (e) { toast(e.message || String(e)); }
});
let fpsBusy = false;
window.api.onPackProgress(p => {
  $('#packStatus').textContent = `Installing ${p.done}/${p.total}…`;
  if (fpsBusy) setStatus(`Installing FPS mods ${p.done}/${p.total}…`);
});
async function installFpsMods() {
  if (fpsBusy) return;
  const version = $('#version').value, loader = $('#loader').value;
  if (loader === 'vanilla') return toast('Pick Fabric, Forge or OptiFine first. Vanilla can\'t run mods.');
  const b = $('#fpsBtn'); b.disabled = true; fpsBusy = true; setStatus('Installing FPS mods…');
  try {
    const r = await window.api.fpsInstall({ version, loader });
    toast(`${r.added.length} FPS mod${r.added.length === 1 ? '' : 's'} ready` + (r.skipped.length ? `. Not available for ${version}: ${r.skipped.join(', ')}` : ''));
    clearBrowsers();
  } catch (e) { toast(e.message || String(e)); }
  fpsBusy = false; b.disabled = false; $('#packStatus').textContent = ''; setStatus('Idle');
}
$('#fpsBtn').addEventListener('click', installFpsMods);

$('#impBtn').addEventListener('click', async () => {
  $('#packStatus').textContent = 'Reading…';
  try {
    const r = await window.api.importPack();
    $('#packStatus').textContent = '';
    if (!r) return;
    $('#loader').value = r.loader;
    if (![...$('#version').options].some(o => o.value === r.version)) $('#version').add(new Option(r.version, r.version));
    $('#version').value = r.version;
    saveSettings(); clearBrowsers(); updateLoaderHint(); refreshInstalled();
    toast(`Installed ${r.installed} file${r.installed === 1 ? '' : 's'}` + (r.failed ? `, ${r.failed} not available for ${r.version}` : '') + `. Set to ${r.version} · ${LOADER_NAME[r.loader]}.`);
  } catch (e) { $('#packStatus').textContent = ''; toast(e.message || String(e)); }
});

/* ---------- servers ---------- */
function renderServers() {
  const box = $('#servers'), list = state.settings.servers || [];
  box.innerHTML = '';
  if (!list.length) { box.innerHTML = '<div class="empty">No servers yet. Add one above.</div>'; return; }
  list.forEach((s, i) => {
    const el = card(`<div class="ph">${letter(s.name)}</div>
      <div class="info"><h3>${esc(s.name)}<span class="dot"></span></h3><p class="addr">${esc(s.addr)} · checking…</p><p class="meta"></p></div>
      <div class="btns"><button class="ghost join">Join</button><button class="ghost rm">Remove</button></div>`, i);
    el.querySelector('.join').addEventListener('click', () => {
      $('nav button[data-tab="play"]').click();
      startGame(s.addr);
    });
    el.querySelector('.rm').addEventListener('click', () => {
      state.settings.servers = (state.settings.servers || []).filter(x => x !== s);
      persist(); renderServers();
    });
    box.appendChild(el);
    window.api.pingServer(s.addr).then(r => {
      if (!el.isConnected) return;
      const dot = el.querySelector('.dot'), addr = el.querySelector('.addr'), meta = el.querySelector('.meta');
      if (!r.online) { addr.textContent = `${s.addr} · offline`; return; }
      dot.classList.add('on');
      addr.textContent = `${s.addr} · ${r.players.online}/${r.players.max} online · ${r.ping} ms${r.version ? ' · ' + r.version : ''}`;
      meta.textContent = r.motd || '';
      if (r.favicon) { const img = new Image(); img.alt = ''; img.src = r.favicon; img.onload = () => { const ph = el.querySelector('.ph'); if (ph) ph.replaceWith(img); }; }
    });
  });
}
$('#srvAdd').addEventListener('click', () => {
  const addr = $('#srvAddr').value.trim();
  if (!/^[A-Za-z0-9._-]+(:\d{1,5})?$/.test(addr)) return toast('Enter a server address like play.example.com');
  const name = $('#srvName').value.trim() || addr;
  state.settings.servers = [...(state.settings.servers || []), { name, addr }];
  persist(); $('#srvName').value = ''; $('#srvAddr').value = ''; renderServers();
});

/* ---------- worlds and backups ---------- */
async function refreshWorlds() {
  const wb = $('#worlds'), bb = $('#backups');
  let worlds = [], backups = [];
  try { [worlds, backups] = await Promise.all([window.api.worldsList(), window.api.backupsList()]); } catch (e) { return toast(e.message || String(e)); }
  wb.innerHTML = worlds.length ? '' : '<div class="empty">No worlds yet. Play once and they show up here.</div>';
  worlds.forEach((w, i) => {
    const el = card(`<div class="ph">${letter(w.name)}</div><div class="info"><h3>${esc(w.name)}</h3><p>${fmtSize(w.size)} · played ${esc(fmtDate(w.mtime))}</p></div><button class="ghost">Back up</button>`, i);
    el.querySelector('button').addEventListener('click', async e => {
      const b = e.currentTarget; b.disabled = true; b.textContent = 'Backing up…';
      try { await window.api.worldBackup(w.name); toast('Backup saved'); refreshWorlds(); }
      catch (err) { b.disabled = false; b.textContent = 'Back up'; toast(err.message || String(err)); }
    });
    wb.appendChild(el);
  });
  bb.innerHTML = backups.length ? '' : '<div class="empty">No backups yet.</div>';
  backups.forEach((b, i) => {
    const el = card(`<div class="ph">⟲</div><div class="info"><h3>${esc(b.world)}</h3><p>${esc(fmtDate(b.mtime))} · ${fmtSize(b.size)}</p></div><div class="btns"><button class="ghost rs">Restore</button><button class="ghost del">Delete</button></div>`, i);
    el.querySelector('.rs').addEventListener('click', async () => {
      if (!confirm(`Restore "${b.world}" from this backup?\nYour current copy of the world is kept as a separate folder.`)) return;
      try { const n = await window.api.backupRestore(b.file); toast(`Restored ${n}`); refreshWorlds(); }
      catch (err) { toast(err.message || String(err)); }
    });
    el.querySelector('.del').addEventListener('click', async () => {
      try { await window.api.backupDelete(b.file); refreshWorlds(); } catch (err) { toast(err.message || String(err)); }
    });
    bb.appendChild(el);
  });
}
$('#backupAll').addEventListener('click', async e => {
  const b = e.currentTarget; b.disabled = true;
  try { const n = await window.api.backupAll(); toast(n ? `Backed up ${n} world${n > 1 ? 's' : ''}` : 'No worlds to back up'); refreshWorlds(); }
  catch (err) { toast(err.message || String(err)); }
  b.disabled = false;
});
$('#savesFolder').addEventListener('click', () => window.api.openSaves());

/* ---------- screenshots ---------- */
async function refreshShots() {
  const box = $('#shots');
  const list = await window.api.shotList().catch(() => []);
  box.innerHTML = list.length ? '' : '<div class="empty">No screenshots yet. Press F2 in the game.</div>';
  const items = list.map((s, i) => {
    const el = document.createElement('div');
    el.className = 'shot'; el.style.animationDelay = `${Math.min(i, 20) * 30}ms`;
    el.innerHTML = `<div class="thumb"></div><div class="s-bar"><span>${esc(fmtDate(s.mtime))}</span><span><button data-a="copy">Copy</button><button data-a="del">Delete</button></span></div>`;
    el.querySelector('.thumb').addEventListener('click', () => window.api.shotOpen(s.name));
    el.querySelector('[data-a="copy"]').addEventListener('click', async () => { await window.api.shotCopy(s.name); toast('Copied to clipboard'); });
    el.querySelector('[data-a="del"]').addEventListener('click', async () => {
      if (!confirm('Delete this screenshot?')) return;
      await window.api.shotDelete(s.name); el.remove();
    });
    box.appendChild(el);
    return { s, el };
  });
  for (const { s, el } of items) {
    if (!el.isConnected) break;
    const url = await window.api.shotThumb(s.name);
    if (url && el.isConnected) { const t = el.querySelector('.thumb'); t.style.backgroundImage = `url("${url}")`; t.classList.add('on'); }
  }
}
$('#shotsFolder').addEventListener('click', () => window.api.openShots());

/* ---------- stats ---------- */
async function refreshStats() {
  const { sessions } = await window.api.stats();
  const dur = s => s.e - s.s;
  const total = sessions.reduce((a, s) => a + dur(s), 0);
  const longest = sessions.reduce((a, s) => Math.max(a, dur(s)), 0);
  const tiles = [
    [fmtDur(total), 'Total playtime'], [String(sessions.length), 'Sessions'],
    [fmtDur(longest), 'Longest session'], [sessions.length ? fmtDur(total / sessions.length) : '0m', 'Average session']
  ];
  $('#tiles').innerHTML = tiles.map(([n, l], i) => `<div class="tile" style="animation-delay:${i * 60}ms"><b>${esc(n)}</b><span>${l}</span></div>`).join('');

  const days = [];
  for (let i = 13; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push({ key: d.toDateString(), label: d.getDate(), ms: 0 }); }
  sessions.forEach(s => { const d = days.find(x => x.key === new Date(s.s).toDateString()); if (d) d.ms += dur(s); });
  const max = Math.max(...days.map(d => d.ms), 1);
  $('#chart').innerHTML = days.map((d, i) =>
    `<div class="dbar" title="${esc(d.key)}: ${fmtDur(d.ms)}"><div class="col"><i style="height:${d.ms ? Math.max(3, d.ms / max * 100) : 0}%;animation-delay:${i * 35}ms"></i></div><span>${d.label}</span></div>`).join('');

  const by = {};
  sessions.forEach(s => { const k = `${s.v} · ${LOADER_NAME[s.l] || s.l}`; (by[k] = by[k] || { ms: 0, n: 0 }); by[k].ms += dur(s); by[k].n++; });
  const rows = Object.entries(by).sort((a, b) => b[1].ms - a[1].ms);
  const box = $('#byver'); box.innerHTML = rows.length ? '' : '<div class="empty">Play for a bit and your stats appear here.</div>';
  rows.forEach(([k, v], i) => {
    box.appendChild(card(`<div class="ph">${letter(k)}</div><div class="info"><h3>${esc(k)}</h3><p>${fmtDur(v.ms)} · ${v.n} session${v.n > 1 ? 's' : ''}</p><div class="meter"><i style="width:${v.ms / rows[0][1].ms * 100}%"></i></div></div>`, i));
  });
}

/* ---------- settings: performance, window, behavior, storage ---------- */
function bindSettings() {
  const s = state.settings;
  $('#jvm').value = s.jvm || ''; $('#jvmArgs').value = s.customArgs || '';
  $('#winW').value = s.winW || ''; $('#winH').value = s.winH || '';
  $('#fullscreen').checked = !!s.fullscreen; $('#hideOnPlay').checked = !!s.hideOnPlay; $('#autoBackup').checked = !!s.autoBackup; $('#autoFps').checked = !!s.autoFps;
}
[['jvm', 'jvm', 'value'], ['jvmArgs', 'customArgs', 'value'], ['winW', 'winW', 'value'], ['winH', 'winH', 'value'],
 ['fullscreen', 'fullscreen', 'checked'], ['hideOnPlay', 'hideOnPlay', 'checked'], ['autoBackup', 'autoBackup', 'checked'], ['autoFps', 'autoFps', 'checked']]
  .forEach(([id, key, prop]) => $('#' + id).addEventListener('change', () => { state.settings[key] = $('#' + id)[prop]; persist(); }));
async function refreshStorage() {
  const rows = await window.api.storageInfo().catch(() => []);
  $('#storage').innerHTML = rows.map(r => `<div><span>${esc(r.label)}</span><b>${fmtSize(r.size)}</b></div>`).join('');
}
$('#clearLogs').addEventListener('click', async () => { const n = await window.api.storageClear('logs'); toast(`Freed ${fmtSize(n)}`); refreshStorage(); });
$('#clearCrash').addEventListener('click', async () => { const n = await window.api.storageClear('crash'); toast(`Freed ${fmtSize(n)}`); refreshStorage(); });

const pageHooks = { servers: renderServers, worlds: refreshWorlds, shots: refreshShots, stats: refreshStats, settings: refreshStorage };

/* ---------- command palette (Ctrl+K) ---------- */
(function palette() {
  const root = $('#palette'), input = $('#pq'), list = $('#plist');
  let items = [], sel = 0;
  const commands = () => [
    ...$$('nav button').map(b => ({ name: 'Go to ' + b.textContent.replace(/^\d+\s*/, '').trim(), run: () => b.click() })),
    { name: 'Play', run: () => startGame() },
    { name: 'Install FPS boost mods', run: () => installFpsMods() },
    { name: 'Open game folder', run: () => window.api.openFolder() },
    { name: 'Back up all worlds', run: async () => { const n = await window.api.backupAll(); toast(n ? `Backed up ${n} world${n > 1 ? 's' : ''}` : 'No worlds to back up'); } },
    ...THEMES.map(t => ({ name: 'Theme: ' + t.name, run: () => { applyTheme(t.id); persist(); } }))
  ];
  function render() {
    const q = input.value.trim().toLowerCase();
    items = commands().filter(c => c.name.toLowerCase().includes(q)).slice(0, 8);
    sel = Math.min(sel, Math.max(0, items.length - 1));
    list.innerHTML = items.map((c, i) => `<div class="p-item${i === sel ? ' sel' : ''}" data-i="${i}">${esc(c.name)}</div>`).join('');
  }
  function open() { root.classList.remove('hidden'); input.value = ''; sel = 0; render(); input.focus(); }
  function close() { root.classList.add('hidden'); }
  function run(i) { const c = items[i]; if (!c) return; close(); c.run(); }
  addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); root.classList.contains('hidden') ? open() : close(); return; }
    if (root.classList.contains('hidden')) return;
    if (e.key === 'Escape') close();
    else if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); render(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(0, sel - 1); render(); }
    else if (e.key === 'Enter') run(sel);
  });
  input.addEventListener('input', () => { sel = 0; render(); });
  list.addEventListener('click', e => { const el = e.target.closest('.p-item'); if (el) run(+el.dataset.i); });
  root.addEventListener('mousedown', e => { if (e.target === root) close(); });
})();


/* ---------- theme picker ---------- */
$('#themes').innerHTML = THEMES.map(t =>
  `<button class="swatch" data-theme="${t.id}" style="--s-bg:${t.bg};--s-fg:${t.fg}"><i></i><span>${t.name}</span></button>`).join('');
$$('.swatch').forEach(s => s.addEventListener('click', () => {
  applyTheme(s.dataset.theme);
  window.api.saveSettings(state.settings);
}));
applyTheme(document.documentElement.dataset.theme);

/* ---------- init ---------- */
(async function init() {
  const splashDone = new Promise(r => setTimeout(r, 2700));
  try {
    state = await window.api.state();
    applyTheme(state.settings.theme || document.documentElement.dataset.theme);
    $('#ram').value = state.settings.ram; $('#ramVal').textContent = state.settings.ram;
    $('#loader').value = state.settings.loader || 'vanilla';
    updateLoaderHint();
    bindSettings();
    renderAccount();
    try {
      const vs = await Promise.race([window.api.versions(), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 6000))]);
      $('#version').innerHTML = vs.map(v => `<option>${esc(v)}</option>`).join('');
      if (state.settings.version && vs.includes(state.settings.version)) $('#version').value = state.settings.version;
    } catch { $('#version').innerHTML = '<option value="">offline</option>'; toast('Could not load versions'); }
  } catch (e) { console.error(e); }
  await splashDone;
  $('#splash').classList.add('out');
  $('#app').classList.remove('hidden');
  setTimeout(() => $('#splash').remove(), 800);
})();
